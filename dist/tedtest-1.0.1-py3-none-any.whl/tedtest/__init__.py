"""TEDTest

A pythonic testing framework that pulls in ideas from
other languages testing frameworks.
"""
__version__ = "1.0.1"

from .UnitTest import *
